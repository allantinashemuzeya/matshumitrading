<!DOCTYPE html>
<html class="no-js no-svg" lang="en-US">

<!-- Mirrored from enginir-demo.creativesplanet.com/engineer/contact-us/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Jan 2021 20:47:50 GMT -->
<!-- Added by HTTrack -->
<meta content="text/html;charset=UTF-8" http-equiv="content-type"/><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="https://gmpg.org/xfn/11" rel="profile">
    <script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
    <title>Contact Us &#8211; </title>
    <style data-type="vc_shortcodes-custom-css">.vc_custom_1556620604270 {
        margin-top: -20px !important;
    }

    .vc_custom_1542271340398 {
        margin-bottom: 0px !important;
    }</style>
    <link href='http://fonts.googleapis.com/' rel='dns-prefetch'/>
    <link href='http://s.w.org/' rel='dns-prefetch'/>
    <link crossorigin href='https://fonts.gstatic.com/' rel='preconnect'/>
    <script>
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/",
            "svgExt": ".svg",
            "source": {"concatemoji": "https:\/\/enginir-demo.creativesplanet.com\/engineer\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.9"}
        };
        !function (a, b, c) {
            function d(a, b) {
                var c = String.fromCharCode;
                l.clearRect(0, 0, k.width, k.height), l.fillText(c.apply(this, a), 0, 0);
                var d = k.toDataURL();
                l.clearRect(0, 0, k.width, k.height), l.fillText(c.apply(this, b), 0, 0);
                var e = k.toDataURL();
                return d === e
            }

            function e(a) {
                var b;
                if (!l || !l.fillText) return !1;
                switch (l.textBaseline = "top", l.font = "600 32px Arial", a) {
                    case"flag":
                        return !(b = d([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819])) && (b = d([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]), !b);
                    case"emoji":
                        return b = d([55357, 56424, 55356, 57342, 8205, 55358, 56605, 8205, 55357, 56424, 55356, 57340], [55357, 56424, 55356, 57342, 8203, 55358, 56605, 8203, 55357, 56424, 55356, 57340]), !b
                }
                return !1
            }

            function f(a) {
                var c = b.createElement("script");
                c.src = a, c.defer = c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }

            var g, h, i, j, k = b.createElement("canvas"), l = k.getContext && k.getContext("2d");
            for (j = Array("flag", "emoji"), c.supports = {
                everything: !0,
                everythingExceptFlag: !0
            }, i = 0; i < j.length; i++) c.supports[j[i]] = e(j[i]), c.supports.everything = c.supports.everything && c.supports[j[i]], "flag" !== j[i] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[j[i]]);
            c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function () {
                c.DOMReady = !0
            }, c.supports.everything || (h = function () {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", h, !1), a.addEventListener("load", h, !1)) : (a.attachEvent("onload", h), b.attachEvent("onreadystatechange", function () {
                "complete" === b.readyState && c.readyCallback()
            })), g = c.source || {}, g.concatemoji ? f(g.concatemoji) : g.wpemoji && g.twemoji && (f(g.twemoji), f(g.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link href='../wp-includes/css/dist/block-library/style.min0606.css?ver=5.2.9' id='wp-block-library-css'
          media='all' rel='stylesheet' type='text/css'/>

    <style id='yith-wcwl-main-inline-css'>
        .wishlist_table .add_to_cart, a.add_to_wishlist.button.alt {
            border-radius: 16px;
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
        }
    </style>
    <link href='../wp-content/plugins/contact-form-7/includes/css/stylesbdeb.css?ver=5.1.3' id='contact-form-7-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/plugins/revslider/public/assets/css/rs652c7.css?ver=6.0.5' id='rs-plugin-settings-css'
          media='all' rel='stylesheet' type='text/css'/>
    <style id='rs-plugin-settings-inline-css'>
        #rs-demo-id {
        }
    </style>


    <link href='../wp-content/plugins/woocommerce-gateway-paypal-express-checkout/assets/css/wc-gateway-ppec-frontend-cart0606.css?ver=5.2.9' id='wc-gateway-ppec-frontend-cart-css'
          media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox0606.css?ver=5.2.9' id='jquery-colorbox-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/plugins/yith-woocommerce-quick-view/assets/css/yith-quick-view0606.css?ver=5.2.9' id='yith-quick-view-css'
          media='all'
          rel='stylesheet' type='text/css'/>
    <style id='yith-quick-view-inline-css'>

        #yith-quick-view-modal .yith-wcqv-main {
            background: #ffffff;
        }

        #yith-quick-view-close {
            color: #cdcdcd;
        }

        #yith-quick-view-close:hover {
            color: #ff0000;
        }
    </style>
    <link href='../wp-content/plugins/woocommerce/assets/css/prettyPhoto0606.css?ver=5.2.9' id='woocommerce_prettyPhoto_css-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='https://fonts.googleapis.com/css?family=Rubik%3A300%2C300italic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic%2Citalic%2Cregular%2Cregular%2C500%7COswald%3A700%2C500%2C600%2C300%7CBarlow+Condensed%3A700%7CRoboto%3A500&amp;ver=5.2.9' id='cspt-all-gfonts-css'
          media='all'
          rel='stylesheet' type='text/css'/>
    <!--[if lt IE 9]>
    <link rel='stylesheet' id='vc_lte_ie9-css'
          href='https://enginir-demo.creativesplanet.com/engineer/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.4'
          type='text/css' media='screen'/>
    <![endif]-->
    <link href='../wp-content/plugins/js_composer/assets/css/js_composer.mindc24.css?ver=6.0.4' id='js_composer_front-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/bootstrap/css/bootstrap.min0606.css?ver=5.2.9' id='bootstrap-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/css/core.min0606.css?ver=5.2.9' id='cspt-core-style-css' media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/css/theme.min0606.css?ver=5.2.9' id='cspt-theme-style-css' media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/magnific-popup/magnific-popup0606.css?ver=5.2.9' id='magnific-popup-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/creativesplanet-base-icons/css/creativesplanet-base-icons0606.css?ver=5.2.9' id='cspt-base-icons-css'
          media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/balloon/balloon.min0606.css?ver=5.2.9' id='balloon-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/cspt-css/4/theme-style.min319f.css?ver=209357' id='cspt-dynamic-style-css'
          media='all' rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/css/responsive.min0606.css?ver=5.2.9' id='cspt-responsive-style-css'
          media='all' rel='stylesheet' type='text/css'/>
    <script src='../wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp'></script>
    <script src='../wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
    <script src='../wp-content/plugins/revslider/public/assets/js/revolution.tools.minf049.js?ver=6.0'></script>
    <script src='../wp-content/plugins/revslider/public/assets/js/rs6.min52c7.js?ver=6.0.5'></script>


    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-32x32.png" rel="icon" sizes="32x32"/>
    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-192x192.png" rel="icon" sizes="192x192"/>
    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-180x180.png" rel="apple-touch-icon-precomposed"/>
    <meta content="https://enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2019/05/cropped-favicon-270x270.png"
          name="msapplication-TileImage"/>

    <script>function setREVStartSize(a) {
        try {
            var b, c = document.getElementById(a.c).parentNode.offsetWidth;
            if (c = 0 === c || isNaN(c) ? window.innerWidth : c, a.tabw = void 0 === a.tabw ? 0 : parseInt(a.tabw), a.thumbw = void 0 === a.thumbw ? 0 : parseInt(a.thumbw), a.tabh = void 0 === a.tabh ? 0 : parseInt(a.tabh), a.thumbh = void 0 === a.thumbh ? 0 : parseInt(a.thumbh), a.tabhide = void 0 === a.tabhide ? 0 : parseInt(a.tabhide), a.thumbhide = void 0 === a.thumbhide ? 0 : parseInt(a.thumbhide), a.mh = void 0 === a.mh || "" == a.mh ? 0 : a.mh, "fullscreen" === a.layout || "fullscreen" === a.l) b = Math.max(a.mh, window.innerHeight); else {
                for (var d in a.gw = Array.isArray(a.gw) ? a.gw : [a.gw], a.rl) (void 0 === a.gw[d] || 0 === a.gw[d]) && (a.gw[d] = a.gw[d - 1]);
                for (var d in a.gh = void 0 === a.el || "" === a.el || Array.isArray(a.el) && 0 == a.el.length ? a.gh : a.el, a.gh = Array.isArray(a.gh) ? a.gh : [a.gh], a.rl) (void 0 === a.gh[d] || 0 === a.gh[d]) && (a.gh[d] = a.gh[d - 1]);
                var e, f = Array(a.rl.length), g = 0;
                for (var d in a.tabw = a.tabhide >= c ? 0 : a.tabw, a.thumbw = a.thumbhide >= c ? 0 : a.thumbw, a.tabh = a.tabhide >= c ? 0 : a.tabh, a.thumbh = a.thumbhide >= c ? 0 : a.thumbh, a.rl) f[d] = a.rl[d] < window.innerWidth ? 0 : a.rl[d];
                for (var d in e = f[0], f) e > f[d] && 0 < f[d] && (e = f[d], g = d);
                var h = c > a.gw[g] + a.tabw + a.thumbw ? 1 : (c - (a.tabw + a.thumbw)) / a.gw[g];
                b = a.gh[g] * h + (a.tabh + a.thumbh)
            }
            void 0 === window.rs_init_css && (window.rs_init_css = document.head.appendChild(document.createElement("style"))), document.getElementById(a.c).height = b, window.rs_init_css.innerHTML += "#" + a.c + "_wrapper { height: " + b + "px }"
        } catch (a) {
            console.log("Failure at Presize of Slider:" + a)
        }
    }</script>
    <style id="kirki-inline-styles">

        @font-face {
            font-display: swap;
            font-family: 'Rubik';
            font-style: normal;
            font-weight: 400;
            src: url(../wp-content/uploads/sites/4/2020/09/iJWZBXyIfDnIV5PNhY1KTN7Z-Yh-B4i1Uw.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Rubik';
            font-style: normal;
            font-weight: 500;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/09/iJWZBXyIfDnIV5PNhY1KTN7Z-Yh-NYi1Uw.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Oswald';
            font-style: normal;
            font-weight: 300;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs169vgUI.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Oswald';
            font-style: normal;
            font-weight: 500;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs18NvgUI.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Oswald';
            font-style: normal;
            font-weight: 600;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs1y9ogUI.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Oswald';
            font-style: normal;
            font-weight: 700;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs1xZogUI.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Barlow Condensed';
            font-style: normal;
            font-weight: 700;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/09/HTxwL3I-JCGChYJ8VI-L6OO_au7B46r2_3I.woff) format('woff');
        }

        @font-face {
            font-display: swap;
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 500;
            src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2019/07/KFOlCnqEu92Fr1MmEU9vAA-290.woff) format('woff');
        }</style>
    <noscript>
        <style> .wpb_animate_when_almost_visible {
            opacity: 1;
        }</style>
    </noscript>

    <style type="text/css">
        @media (max-width:768px){
            #post-8593 > div > div.vc_row.wpb_row.vc_row-fluid.cspt-overflow-visible.cspt-row.cspt-bg-color-yes.cspt-bg-color-white.cspt-zindex-2{
                margin-top:-130px!important;
            }
        }

    </style>
</head>

<body  class="page-template-default page page-id-8593 woocommerce-no-js cspt-sidebar-no wpb-js-composer js-comp-ver-6.0.4 vc_responsive">




<div class="site cspt-parent-header-style-3" id="page">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>
    <header class="site-header cspt-header-style-3" id="masthead">
        <div class="cspt-header-overlay">
            <div class="cspt-pre-header-wrapper  cspt-bg-color-transparent cspt-color-blackish">
                <div class="container">
                    <div class="d-flex justify-content-between">
                        <div class="cspt-pre-header-left" style="color:#fff"><i class="cspt-base-icon-marker"></i>Matshumi
                            Trading (Pty) Ltd

                            Wendywood
                            2144
                        </div><!-- .cspt-pre-header-left -->
                        <div class="cspt-pre-header-right" style="color:#fff">
                            <ul class="cspt-contact-info">
                                <li><i class="cspt-base-icon-phone"></i> Make a call : 087 821 7562</li>
                                <li>
                                    <ul class="cspt-social-links">
                                        <li class="cspt-social-li cspt-social-facebook "><a href="#"
                                                                                            target="_blank"><span><i
                                                class="cspt-base-icon-facebook-squared"
                                                style="background-color: #fff"></i></span></a></li>
                                        <li class="cspt-social-li cspt-social-twitter "><a href="#"
                                                                                           target="_blank"><span><i
                                                class="cspt-base-icon-twitter"
                                                style="background-color: #fff"></i></span></a></li>
                                        <li class="cspt-social-li cspt-social-linkedin "><a href="#"
                                                                                            target="_blank"><span><i
                                                class="cspt-base-icon-linkedin-squared"
                                                style="background-color: #fff"></i></span></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div><!-- .cspt-pre-header-right -->
                    </div><!-- .justify-content-between -->
                </div><!-- .container -->
            </div><!-- .cspt-pre-header-wrapper -->
            <div class="cspt-header-height-wrapper" style="min-height:90px;">
                <div class="cspt-header-wrapper cspt-sticky-logo-no cspt-responsive-logo-no
                cspt-responsive-header-bgcolor-white cspt-header-sticky-yes cspt-sticky-type- cspt-sticky-bg-color-white">
                    <div class="container">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="cspt-logo-menuarea cspt-header-wrapper cspt-bg-color-white"
                                 style="border-bottom-left-radius: 50px; border-top-left-radius:50px ">
                                <div class="site-branding cspt-logo-area">
                                    <div class="wrap">
                                        <h1 class="site-title"><a href="http://matshumitrading.co.za" rel="home"><img
                                                alt="Engineer"
                                                class="cspt-main-logo"
                                                height="100%" src="../media_content/logo/logo-removebg-preview.png"
                                                title="Matshumi Trading Logo"/></a></h1></div><!-- .wrap -->
                                </div><!-- .site-branding -->

                                <button class="nav-menu-toggle" id="menu-toggle">
                                    <i class="cspt-base-icon-menu-1"></i>
                                </button>
                                <!-- Top Navigation Menu -->
                                <div class="navigation-top">
                                    <div class="wrap">
                                        <nav aria-label="Top Menu"
                                             class="main-navigation cspt-navbar  cspt-main-active-color-globalcolor cspt-dropdown-active-color-globalcolor"
                                             id="site-navigation">
                                            <div class="menu-main-menu-container">
                                                <ul class="menu" id="cspt-top-menu">
                                                    <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent  menu-item-9883"
                                                        id="menu-item-9883">
                                                        <a href="http://matshumitrading.co.za">Home</a>
                                                    </li>


                                                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9906"
                                                        id="menu-item-9906">
                                                        <a href="#">Supply</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10891"
                                                                id="menu-item-10891">
                                                                <a href="#">Power Tools</a></li>

                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10891"
                                                                id="menu-item-10891">
                                                                <a href="#">Bolts and Nuts</a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10892"
                                                                id="menu-item-10892">
                                                                <a href="#">Diamond Coring
                                                                </a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10893"
                                                                id="menu-item-10893">
                                                                <a href="#">Cutting Systems</a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10894"
                                                                id="menu-item-10894">
                                                                <a href="#">Concrete, Rock & Masonry Drilling and
                                                                    Breaking Systems
                                                                </a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10895"
                                                                id="menu-item-10895">
                                                                <a href="#">Chemical & Expansion Anchoring Systems</a>
                                                            </li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-cspt-service menu-item-10896"
                                                                id="menu-item-10896">
                                                                <a href="#">Machining & Fabrication</a></li>


                                                        </ul>
                                                    </li>

                                                    <!--<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9910"-->
                                                    <!--    id="menu-item-9910">-->
                                                    <!--    <a href="index.html/#about-us">About Us</a></li>-->

                                                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9910"
                                                        id="menu-item-9910">
                                                        <a href="#">Contact Us</a></li>
                                                </ul>
                                            </div>
                                        </nav><!-- #site-navigation -->
                                    </div><!-- .wrap -->
                                </div><!-- .navigation-top -->


                            </div>

                            <div class="cspt-header-button">
                                <a href="#contact-us">Get a Quote</a>
                            </div>

                        </div><!-- .justify-content-between -->
                    </div><!-- .container -->
                </div><!-- .cspt-header-wrapper -->
            </div><!-- .cspt-header-height-wrapper -->
        </div>

    </header><!-- #masthead -->
    <div class="site-content-contain ">
        <div class="site-content container" id="content">

            <div class="content-area " id="primary">
                <main class="site-main cspt-page-content-wrapper" id="main">

                    <article class="post-8593 page type-page status-publish hentry" id="post-8593">
                        <div class="entry-content">
                            <style type="text/css">
                                @media only screen and(max-width: 348px) {
                                    #post-8593 > div > div.vc_row.wpb_row.vc_row-fluid.cspt-overflow-visible.cspt-row.cspt-bg-color-yes.cspt-bg-color-white.cspt-zindex-2 {
                                        margin-top: -145px;
                                    }
                                }
                            </style>
                            <div class=" vc_row wpb_row vc_row-fluid cspt-overflow-visible cspt-row cspt-bg-color-yes cspt-bg-color-white cspt-zindex-2" data-vc-full-width="true" data-vc-full-width-init="false"
                                 style="">

                                <div class="wpb_column vc_column_container vc_col-sm-4 cspt-column cspt-bg-color-yes cspt-bg-color-transparent cspt-zindex-zero">
                                    <div class="vc_column-inner ">


                                        <div class="wpb_wrapper">
                                            <div class="cspt-ihbox cspt-ihbox-style-hsbox   cspt-reverse-heading-yes">
                                                <div class="cspt-ihbox-contents">
                                                    <div class="cspt-ihbox-subheading"><h4 class="vc_custom_heading">GET
                                                        IN TOUCH</h4></div>
                                                    <div class="cspt-ihbox-heading"><h2 class="vc_custom_heading">Do You
                                                        Have <strong>Any Questions?</strong></h2></div>
                                                </div><!-- .cspt-ihbox-contents -->
                                            </div>

                                            <div class="wpb_text_column wpb_content_element  vc_custom_1556620604270">

                                            </div>
                                            <div class="cspt-ihbox cspt-ihbox-style-7 ">
                                                <div class="cspt-ihbox-contents">
                                                    <div class="cspt-ihbox-headingicon d-flex align-items-center">
                                                        <div class="cspt-ihbox-icon">
                                                            <div class="cspt-ihbox-icon-wrapper"><i
                                                                    class="cspt-enginir-icon cspt-enginir-icon-mail"></i>
                                                            </div>
                                                        </div>
                                                        <div class="cspt-ihbox-contents">
                                                            <div class="cspt-ihbox-heading"><h2
                                                                    class="vc_custom_heading"><a href="mailto:mathew@matshumitrading.co.za">mathew@matshumitrading.co.za</a> </h2>
                                                            </div>
                                                            <div class="cspt-ihbox-content">Email address</div>
                                                        </div><!-- .cspt-ihbox-contents -->
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="cspt-ihbox cspt-ihbox-style-7 ">
                                                <div class="cspt-ihbox-contents">
                                                    <div class="cspt-ihbox-headingicon d-flex align-items-center">
                                                        <div class="cspt-ihbox-icon">
                                                            <div class="cspt-ihbox-icon-wrapper"><i
                                                                    class="cspt-enginir-icon cspt-enginir-icon-call"></i>
                                                            </div>
                                                        </div>
                                                        <div class="cspt-ihbox-contents">
                                                            <div class="cspt-ihbox-heading">
                                                                <h2 class="vc_custom_heading">087 821 7562</h2>
                                                            </div>
                                                            <div class="cspt-ihbox-content">Phone Line</div>
                                                        </div><!-- .cspt-ihbox-contents -->
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="cspt-ihbox cspt-ihbox-style-7 ">
                                                <div class="cspt-ihbox-contents">
                                                    <div class="cspt-ihbox-headingicon d-flex align-items-center">
                                                        <div class="cspt-ihbox-icon">
                                                            <div class="cspt-ihbox-icon-wrapper"><i
                                                                    class="cspt-enginir-icon cspt-enginir-icon-skyline"></i>
                                                            </div>
                                                        </div>
                                                        <div class="cspt-ihbox-contents">
                                                            <div class="cspt-ihbox-heading"><h2
                                                                    class="vc_custom_heading">
                                                                P. O Box 76570
                                                                Wendywood
                                                                2144</h2>
                                                            </div>
                                                            <div class="cspt-ihbox-content">Our address</div>
                                                        </div><!-- .cspt-ihbox-contents -->
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>


                                <div class="wpb_column vc_column_container vc_col-sm-8 cspt-column cspt-bg-color-yes cspt-bg-color-transparent cspt-zindex-2">
                                    <div class="vc_column-inner ">


                                        <div class="wpb_wrapper" id="contact-us">
                                            <div class="wpcf7" dir="ltr" id="wpcf7-f8606-p8593-o2" lang="en-US"
                                                 role="form">
                                                <div class="screen-reader-response"></div>

                                                <form action="http://matshumitrading.co.za/sendmail.php"
                                                      class="" method="post">

                                                    <div class="cspt-main-form">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <div class="input-group"><span
                                                                        class="wpcf7-form-control-wrap your-name">
                                                                    <input  aria-invalid="false"
                                                                            class="wpcf7-form-control wpcf7-text"
                                                                            name="name"
                                                                            placeholder="Your Name *"
                                                                            size="40"
                                                                            type="text"
                                                                            value="" required/></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="input-group"><span
                                                                        class="wpcf7-form-control-wrap your-email">
                                                                    <input aria-invalid="false" aria-required="true"
                                                                           class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required
                                                                    wpcf7-validates-as-email"
                                                                           name="email"
                                                                           placeholder="Your Email *"
                                                                           size="40" type="email"
                                                                           value="" required/></span></div>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="input-group input-button"><span
                                                                        class="wpcf7-form-control-wrap website-url"><input
                                                                        aria-invalid="false" class="wpcf7-form-control wpcf7-text" name="website-url"
                                                                        placeholder="Website URL" size="40"
                                                                        type="text" value="" required/></span>
                                                                </div>
                                                            </div>

                                                            <div class="col-sm-12">
                                                                <div class="input-group input-button"><span
                                                                        class="wpcf7-form-control-wrap website-url"><input
                                                                        aria-invalid="false" class="wpcf7-form-control wpcf7-text" name="phone"
                                                                        placeholder="Phone Number" size="40"
                                                                        type="text" value="" required/></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="input-group input-button"><span
                                                                        class="wpcf7-form-control-wrap message"><textarea
                                                                        aria-invalid="false" class="wpcf7-form-control wpcf7-textarea" cols="40"
                                                                        name="message"
                                                                        placeholder="Message"
                                                                        rows="5" required></textarea></span></div>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="input-group input-button"><input
                                                                        class=" " type="submit"
                                                                         value=" <?php $formFeedBack =  $_GET[formFeedBack];
                                                                                if($formFeedBack !== null){
                                                                                    echo $formFeedBack;
                                                                                    // header("Location:contact.php");
                                                                                }else{
                                                                                    echo 'Send Message';
                                                                                }?>
                                                                        "/></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="wpcf7-response-output wpcf7-display-none"></div>
                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div class="vc_row-full-width vc_clearfix"></div>
                            <div class="vc_row wpb_row vc_row-fluid cspt-row cspt-bg-color-yes cspt-bg-color-transparent cspt-zindex-zero vc_row-no-padding" data-vc-full-width="true"
                                 data-vc-full-width-init="false"
                                 data-vc-stretch-content="true">

                                <div class="wpb_column vc_column_container vc_col-sm-12 cspt-column cspt-bg-color-yes cspt-bg-color-transparent cspt-zindex-zero">
                                    <div class="vc_column-inner ">


                                        <div class="wpb_wrapper">

                                            <div class="wpb_raw_code wpb_content_element wpb_raw_html vc_custom_1542271340398">
                                                <div class="wpb_wrapper">
                                                    <div style="height:450px;">
                                                        <iframe allowfullscreen
                                                                height="450" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14338.33894943585!2d28.148668719151715!3d-26.04713990645408!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e956d002ad190f9%3A0x377c907a2e57549c!2sKlipfontein%20View%2C%20Lethabong%2C%201685!5e0!3m2!1sen!2sza!4v1610415810394!5m2!1sen!2sza" style="border:0; width:100%;"
                                                                width="600"></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div class="vc_row-full-width vc_clearfix"></div>
                            <h3 class="cspt-hide">Contact Us</h3>
                        </div><!-- .entry-content -->
                    </article><!-- #post-## -->
                </main><!-- #main -->
            </div><!-- #primary -->


        </div><!-- #content -->

        <footer class="site-footer  cspt-color-white cspt-bg-color-blackish cspt-footer-menu-yes cspt-footer-widget-yes"
                id="colophon">
            <div class="cspt-footer-big-area-wrapper">
                <div class="footer-wrap cspt-footer-big-area container">

                    <div class="cspt-footer-big-right">
                        <script>(function () {
                            if (!window.mc4wp) {
                                window.mc4wp = {
                                    listeners: [],
                                    forms: {
                                        on: function (event, callback) {
                                            window.mc4wp.listeners.push({
                                                event: event,
                                                callback: callback
                                            });
                                        }
                                    }
                                }
                            }
                        })();
                        </script>

                    </div>
                </div>

                <div class="cspt-footer-text-area  cspt-bg-color-blackish">
                    <div class="container">
                        <div class="cspt-footer-text-inner">
                            <div class="row">

                                <div class="cspt-footer-copyright col-md-6">
                                    <div class="cspt-footer-copyright-text-area">
                                        Copyright © 2021 All Rights Reserved.<br/> Designed by <a
                                            href="mailto:allan.thecodemaster@gmail.com" style="font-weight: 700">Allan Muzeya</a>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="cspt-footer-menu-area">
                                        <div class="menu-footermenu-container">
                                            <ul class="cspt-footer-menu" id="cspt-footer-menu">
                                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9852"
                                                    id="menu-item-9852">
                                                    <a>Privacy Policy</a></li>
                                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9853"
                                                    id="menu-item-9853">
                                                    <a>Legal Terms</a></li>
                                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9854"
                                                    id="menu-item-9854">
                                                    <a>Support</a></li>
                                            </ul>
                                        </div>
                                    </div><!-- .cspt-footer-menu-area -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer><!-- #colophon -->
    </div><!-- .site-content-contain -->
</div><!-- #page -->
<a class="scroll-to-top" href="#"><i class="cspt-base-icon-up-open-big"></i></a>

<div id="yith-quick-view-modal">

    <div class="yith-quick-view-overlay"></div>


</div>


<link href='../wp-content/plugins/enginir-addons/libraries/cspt-enginir-icon/flaticon0606.css?ver=5.2.9' id='cspt_enginir_icon-css'
      media='all' rel='stylesheet'
      type='text/css'/>





<script src='../wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min13ac.js?ver=1.4.21'>


</script>

<script src='../wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min005e.js?ver=3.1.6'></script>
<script src='../wp-includes/js/underscore.min4511.js?ver=1.8.3'></script>



<!--[if lte IE 9]>
<![endif]-->
</body>

<!-- Mirrored from enginir-demo.creativesplanet.com/engineer/contact-us/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Jan 2021 20:47:53 GMT -->
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced
Database Caching 2/93 queries in 0.057 seconds using disk (Request-wide modification query)

-->



<!--  <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="https://gmpg.org/xfn/11" rel="profile">
    <title>Contact Us &#8211; </title>
    <style data-type="vc_shortcodes-custom-css">.vc_custom_1556620604270 {
        margin-top: -20px !important;
    }

    .vc_custom_1542271340398 {
        margin-bottom: 0px !important;
    }</style>
    <link href='http://fonts.googleapis.com/' rel='dns-prefetch'/>
    <link href='http://s.w.org/' rel='dns-prefetch'/>
    <link crossorigin href='https://fonts.gstatic.com/' rel='preconnect'/>

    <style>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link href='../wp-includes/css/dist/block-library/style.min0606.css?ver=5.2.9' id='wp-block-library-css'
          media='all' rel='stylesheet' type='text/css'/>

    <style id='yith-wcwl-main-inline-css'>
        .wishlist_table .add_to_cart, a.add_to_wishlist.button.alt {
            border-radius: 16px;
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
        }
    </style>
    <link href='../wp-content/plugins/contact-form-7/includes/css/stylesbdeb.css?ver=5.1.3' id='contact-form-7-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/plugins/revslider/public/assets/css/rs652c7.css?ver=6.0.5' id='rs-plugin-settings-css'
          media='all' rel='stylesheet' type='text/css'/>
    <style id='rs-plugin-settings-inline-css'>
        #rs-demo-id {
        }
    </style>



    <style id='yith-quick-view-inline-css'>

        #yith-quick-view-modal .yith-wcqv-main {
            background: #ffffff;
        }

        #yith-quick-view-close {
            color: #cdcdcd;
        }

        #yith-quick-view-close:hover {
            color: #ff0000;
        }
    </style>

    <link href='https://fonts.googleapis.com/css?family=Rubik%3A300%2C300italic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic%2Citalic%2Cregular%2Cregular%2C500%7COswald%3A700%2C500%2C600%2C300%7CBarlow+Condensed%3A700%7CRoboto%3A500&amp;ver=5.2.9' id='cspt-all-gfonts-css'
          media='all'
          rel='stylesheet' type='text/css'/>

    <link href='../wp-content/plugins/js_composer/assets/css/js_composer.mindc24.css?ver=6.0.4' id='js_composer_front-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/bootstrap/css/bootstrap.min0606.css?ver=5.2.9' id='bootstrap-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/css/core.min0606.css?ver=5.2.9' id='cspt-core-style-css' media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/css/theme.min0606.css?ver=5.2.9' id='cspt-theme-style-css' media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/magnific-popup/magnific-popup0606.css?ver=5.2.9' id='magnific-popup-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/creativesplanet-base-icons/css/creativesplanet-base-icons0606.css?ver=5.2.9' id='cspt-base-icons-css'
          media='all'
          rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/libraries/balloon/balloon.min0606.css?ver=5.2.9' id='balloon-css'
          media='all' rel='stylesheet'
          type='text/css'/>
    <link href='../wp-content/cspt-css/4/theme-style.min319f.css?ver=209357' id='cspt-dynamic-style-css'
          media='all' rel='stylesheet' type='text/css'/>
    <link href='../wp-content/themes/enginir/css/responsive.min0606.css?ver=5.2.9' id='cspt-responsive-style-css'
          media='all' rel='stylesheet' type='text/css'/>


    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-32x32.png" rel="icon" sizes="32x32"/>
    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-192x192.png" rel="icon" sizes="192x192"/>
    <link href="../wp-content/uploads/sites/4/2019/05/cropped-favicon-180x180.png" rel="apple-touch-icon-precomposed"/>
    <meta content="https://enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2019/05/cropped-favicon-270x270.png"
          name="msapplication-TileImage"/>


    <style id="kirki-inline-styles">

    @font-face {
        font-display: swap;
        font-family: 'Rubik';
        font-style: normal;
        font-weight: 400;
        src: url(../wp-content/uploads/sites/4/2020/09/iJWZBXyIfDnIV5PNhY1KTN7Z-Yh-B4i1Uw.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Rubik';
        font-style: normal;
        font-weight: 500;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/09/iJWZBXyIfDnIV5PNhY1KTN7Z-Yh-NYi1Uw.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Oswald';
        font-style: normal;
        font-weight: 300;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs169vgUI.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Oswald';
        font-style: normal;
        font-weight: 500;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs18NvgUI.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Oswald';
        font-style: normal;
        font-weight: 600;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs1y9ogUI.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Oswald';
        font-style: normal;
        font-weight: 700;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/07/TK3_WkUHHAIjg75cFRf3bXL8LICs1xZogUI.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Barlow Condensed';
        font-style: normal;
        font-weight: 700;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2020/09/HTxwL3I-JCGChYJ8VI-L6OO_au7B46r2_3I.woff) format('woff');
    }

    @font-face {
        font-display: swap;
        font-family: 'Roboto';
        font-style: normal;
        font-weight: 500;
        src: url(//enginir-demo.creativesplanet.com/engineer/wp-content/uploads/sites/4/2019/07/KFOlCnqEu92Fr1MmEU9vAA-290.woff) format('woff');
    }</style>
    <noscript>
        <style> .wpb_animate_when_almost_visible {
            opacity: 1;
        }</style>
    </noscript>

    <style type="text/css">
        @media (max-width:768px){
            #post-8593 > div > div.vc_row.wpb_row.vc_row-fluid.cspt-overflow-visible.cspt-row.cspt-bg-color-yes.cspt-bg-color-white.cspt-zindex-2{
                margin-top:-130px!important;
            }
        }

    </style>-->