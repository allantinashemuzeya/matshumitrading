<?php

$toMail = 'mathew@matshumitrading.co.za';
$name = $_POST['name'];
$fromMail = $_POST['email'];
$phone = $_POST['phone'];
$subject = 'Enquiry From the website';
$website_url = $_POST['website_url'];
$message = $_POST['message'];
$headers = 'From: '.$fromMail;

$mail = mail($toMail, $subject, $message, $headers);

header("Location:contact.php/?formFeedBack=".urlencode('Thank you your message has been sent.'));

?>